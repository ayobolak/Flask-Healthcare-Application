from pymongo import MongoClient
import csv

# Connect to MongoDB
client = MongoClient("mongodb://localhost:27017/")
db = client["income_survey"]
collection = db["responses"]

# Get all entries
records = list(collection.find())

# Define the CSV filename and headers
filename = "users.csv"
fieldnames = ["age", "gender", "total_income", "utilities", "entertainment", "school_fees", "shopping", "healthcare"]

# Write to CSV
with open(filename, mode='w', newline='') as file:
    writer = csv.DictWriter(file, fieldnames=fieldnames)
    writer.writeheader()
    for record in records:
        expenses = record.get("expenses", {})
        writer.writerow({
            "age": record.get("age", ""),
            "gender": record.get("gender", ""),
            "total_income": record.get("total_income", 0),
            "utilities": expenses.get("utilities", 0),
            "entertainment": expenses.get("entertainment", 0),
            "school_fees": expenses.get("school_fees", 0),
            "shopping": expenses.get("shopping", 0),
            "healthcare": expenses.get("healthcare", 0)
        })

print(f"✅ Exported {len(records)} users to {filename}")
